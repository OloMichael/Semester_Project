#include <iostream>
#include <vector>
using namespace std;



int main() {
	
	while (true) {
		cout<<"School Management System"<<endl;
		cout<<"1. Add student"<<endl;
		cout<<"2. Teacher details"<<endl;
		cout<<"3. Update Grade"<<endl;
		cout<<"4. Display Course Information"<<endl;
		cout<<"5. Display student Details"<<endl;
		cout<<"6. Exit"<<endl;
		cout<<"Enter choice: ";
		int choice;
		cin >> choice;
		switch (choice ) {
			
			case 1:{
//				Add Student
				string name,sex;
				int rollnumber;
				cout<<"Enter student name: ";
				cin>> name;
				cout<<"Enter roll number: ";
				cin>> rollnumber;
				cout<<"enter student sex: ";
				cin>>sex;
				break;
			}
			
			case 2:{
//				Teacher Details
				cout<<" name-sex-course-id "<<endl;
				cout<<"John male comskills 102 "<<endl;
				cout<<"Musa male french 101 "<<endl;
				cout<<"Mavis female probability 151 "<<endl;
				cout<<"Michael male c++ 166";
				cout<<endl;
				
		
                break;
				}
			case 3:{
//			Student Grade Update	
			cout<<"id- name- grade- gpa"<<endl;
			cout<<"001 Mike B+ 3.5"<<endl;
			cout<<"002 Daniel C+ 2.6"<<endl;
			cout<<"004 Opoku A 4.0 "<<endl;
			cout<<"003 Juana D 1.0"<<endl;
			cout<<endl;
				break;
				}
			case 4:{
//				Course Informatiom
				cout<<" code- name- hours"<<endl;
				cout<<"comp166 C++ 3 "<<endl;
				cout<<"Stat151 probability 3"<<endl;
				cout<<"Uenr102 academic writing 2"<<endl;
				cout<<"Uenr101 french 2 "<<endl;
				cout<<endl;
				break;
				}
			case 5:{
//				Display Student Details
               cout<<"student details "<<endl<<endl;
               cout<<"name- sex- class-course- grade "<<endl;
               cout<<"john male block1 maths C "<<endl;
               cout<<"blessing block3 c++ B+ "<<endl;
               cout<<"ollo block6 french A "<<endl;
               cout<<endl;
				break;
			}
			case 6:{
			
				break;
			}
			default:
						std::cout<<"Invalid choice";
}}
				
return 0;
  
  
  }	        

